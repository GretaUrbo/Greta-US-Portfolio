Projekte analizuojamas dantų pastų asortimentas elektroninėje parduotuvėje eurovaistine.lt bei asortimente esančių dantų pastų sudėtis.

Failai:

Eurovaistine-scraping.ipynb --> e.parduotuvės scrape'inimo kodas
eurovaistineNEWW.csv --> Eurovaistine-scraping.ipynb  produktas
ingredients.csv --> iš viešų šaltinių surinkta informacija apie dažniausiai naudojamus dantų pastų ingredientus ir jų poveikį
ingredients_translation.csv --> ingredientų vertimas (LT-EN)
toothpaste_ingredients_alternatives.csv --> pripažintų kokybiškų ir biudžetinių alternatyvų sąrašas
Eurovaistine-harmonization-toMySql.ipynb --> duomenų valymas ir eksportavimas į MySQL DB
CREATE_TABLES_MYSQL.sql --> duomenų bazės ir lentelių kūrimas MySQL Workbench
tootpastes_analysis.pbix --> analizė Power BI aplinkoje



------------------------------------------

The project analyzes the assortment of toothpastes available in the online store eurovaistine.lt and the composition of the toothpastes included in the assortment.

Files:

Eurovaistine-scraping.ipynb → Web scraping code for the online store
eurovaistineNEWW.csv → Output product data from Eurovaistine-scraping.ipynb
ingredients.csv → Information collected from public sources about the most commonly used toothpaste ingredients and their effects
ingredients_translation.csv → Translation of ingredients (LT-EN)
toothpaste_ingredients_alternatives.csv → A list of recognized high-quality and budget-friendly alternatives
Eurovaistine-harmonization-toMySql.ipynb → Data cleaning and export to MySQL database
CREATE_TABLES_MYSQL.sql → SQL script for creating the database and tables in MySQL Workbench
toothpastes_analysis.pbix → Analysis in the Power BI environment
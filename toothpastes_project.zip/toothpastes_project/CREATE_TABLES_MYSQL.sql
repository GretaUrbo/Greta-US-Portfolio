CREATE TABLE `eurovaistine_toothpastes`(
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `product_name` VARCHAR(255) NOT NULL,
    `url` VARCHAR(255) NOT NULL,
    `ingredient` VARCHAR(255) NOT NULL,
    `image_url` VARCHAR(255) NOT NULL,
    `Producer` VARCHAR(255) NOT NULL,
    `amount` INT NOT NULL,
    `amount_dim` VARCHAR(255) NOT NULL,
    `density_g_per_mL` VARCHAR(255) NOT NULL,
    `RDA` INT,
    `price_regular_eur` DECIMAL(8, 2) NOT NULL,
    `price_discount_eur` DECIMAL(8,2) NOT NULL
    );
    
CREATE TABLE `classification` (
	`Class` VARCHAR(255) NOT NULL,
    `Class_LT` VARCHAR(255) NOT NULL,
    `Class_description` TEXT
);

CREATE TABLE `RDA` (
	`RDA` VARCHAR(255) NOT NULL,
    `Meaning` VARCHAR(255) NOT NULL
);

CREATE TABLE `ingredients_alternatives` (
	`Budget ingredient` VARCHAR(255) NOT NULL,
    `Quality ingredient` VARCHAR(255) NOT NULL,
    `Difference` TEXT
);

CREATE TABLE `ingredients` (
	`ingredient` VARCHAR(255) NOT NULL,
    `category` VARCHAR(255) NOT NULL,
    `ingredient_description` TEXT NOT NULL,
    `usability` VARCHAR(255),
    `safety` VARCHAR(255)
    
);

